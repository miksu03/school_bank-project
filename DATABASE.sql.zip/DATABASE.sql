-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: mysli.oamk.fi
-- Generation Time: 27.04.2023 klo 13:51
-- Palvelimen versio: 10.5.18-MariaDB-0+deb11u1
-- PHP Version: 7.3.31-1~deb10u3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opisk_t2rymi00`
--

-- --------------------------------------------------------

--
-- Rakenne taululle `account`
--

CREATE TABLE `account` (
  `idCard` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `maxCredit` double DEFAULT NULL,
  `idCustomer` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Vedos taulusta `account`
--

INSERT INTO `account` (`idCard`, `value`, `maxCredit`, `idCustomer`, `id`) VALUES
(1, 55650.87, -1, 1, 1),
(2, 2303.34, 2500, 2, 2);

-- --------------------------------------------------------

--
-- Rakenne taululle `card`
--

CREATE TABLE `card` (
  `idCard` int(11) NOT NULL,
  `cardNumber` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pinCode` varchar(255) DEFAULT NULL,
  `Account_idCard` int(11) DEFAULT NULL,
  `Customer_idCustomer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Vedos taulusta `card`
--

INSERT INTO `card` (`idCard`, `cardNumber`, `password`, `pinCode`, `Account_idCard`, `Customer_idCustomer`) VALUES
(1, '06000DE52F', '$2a$12$SIgYvkk.42bDvqap8O2Aducmr0bZqFeriT8.9iocdX3JvEbbd2B5G', '$2a$12$SIgYvkk.42bDvqap8O2Adu1grkdlAJbhDZ9f2nH5Ky0us5Ieydmja', 1, 1),
(2, '06000649CE', '$2a$12$SIgYvkk.42bDvqap8O2Adu78LkCtIHPyHcXt5x7nLmmcO3nIcUlji', '$2a$12$SIgYvkk.42bDvqap8O2AduhPzbqepqcD6u2eheI8usSm6hzHw2qqe', 2, 2);

-- --------------------------------------------------------

--
-- Rakenne taululle `customer`
--

CREATE TABLE `customer` (
  `idCustomer` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `surName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Vedos taulusta `customer`
--

INSERT INTO `customer` (`idCustomer`, `name`, `surName`) VALUES
(1, 'Enni', 'Linna'),
(2, 'Eetu', 'Laine');

-- --------------------------------------------------------

--
-- Rakenne taululle `events`
--

CREATE TABLE `events` (
  `idEvent` int(11) NOT NULL,
  `idAccount` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Vedos taulusta `events`
--

INSERT INTO `events` (`idEvent`, `idAccount`, `value`, `date`) VALUES
(2, 2, -123.45, '2023-04-26 08:00:00'),
(3, 1, -234.56, '2023-04-27 10:15:00'),
(4, 2, 345.67, '2023-04-28 12:30:00'),
(5, 2, -456.78, '2023-04-29 14:45:00'),
(6, 1, 567.89, '2023-04-30 17:00:00'),
(7, 2, -678.9, '2023-05-01 19:15:00'),
(8, 2, -789.01, '2023-05-02 21:30:00'),
(9, 2, 890.12, '2023-05-03 23:45:00'),
(10, 2, -901.23, '2023-05-05 02:00:00'),
(11, 2, -101.23, '2023-05-06 04:15:00'),
(12, 1, -202.34, '2023-05-07 06:30:00'),
(13, 1, 303.45, '2023-05-08 08:45:00'),
(14, 1, -404.56, '2023-05-09 11:00:00'),
(15, 2, 505.67, '2023-05-10 13:15:00'),
(16, 2, -606.78, '2023-05-11 15:30:00'),
(17, 2, -707.89, '2023-05-12 17:45:00'),
(18, 1, 808.9, '2023-05-13 20:00:00'),
(19, 2, -909.01, '2023-05-14 22:15:00'),
(20, 2, 1010.12, '2023-05-16 00:30:00'),
(21, 2, -1111.23, '2023-05-17 02:45:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Account_Customer1` (`idCustomer`),
  ADD KEY `fk_Account_Card1` (`idCard`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`idCard`) USING BTREE,
  ADD KEY `fk_Card_Account_idx` (`Account_idCard`),
  ADD KEY `fk_Card_Customer1_idx` (`Customer_idCustomer`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idCustomer`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`idEvent`),
  ADD UNIQUE KEY `idEvent` (`idEvent`);

--
-- Rajoitteet vedostauluille
--

--
-- Rajoitteet taululle `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `fk_Account_Card1` FOREIGN KEY (`idCard`) REFERENCES `card` (`idCard`),
  ADD CONSTRAINT `fk_Account_Customer1` FOREIGN KEY (`idCustomer`) REFERENCES `customer` (`idCustomer`);

--
-- Rajoitteet taululle `card`
--
ALTER TABLE `card`
  ADD CONSTRAINT `card_ibfk_1` FOREIGN KEY (`Account_idCard`) REFERENCES `account` (`id`),
  ADD CONSTRAINT `fk_Card_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `customer` (`idCustomer`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
